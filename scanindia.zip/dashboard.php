<?php require_once 'includes/header.php'; ?>

<!-- Page Content -->
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <h1> Devices </h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div id="map">

            </div>
        </div>
    </div>
    <!-- /.row -->

</div>
<!-- /.container -->
<?php require_once 'includes/footer.php'; ?>